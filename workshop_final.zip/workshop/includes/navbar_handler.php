<?php
// Function to check if current page matches the given URL
function isActive($url) {
    $current_page = basename($_SERVER['PHP_SELF']);
    
    // Get hash fragment if present in the URL parameter
    $url_parts = explode('#', $url);
    $base_url = $url_parts[0];
    $fragment = isset($url_parts[1]) ? $url_parts[1] : '';
    
    // Special case for services section in index.php
    if ($url === 'index.php#services') {
        // Check if we're on index.php and section=services is in the query string or fragment is in the actual URL
        if ($current_page === 'index.php') {
            // Check if 'services' is in the URL (fragment/anchor)
            $actual_uri = $_SERVER['REQUEST_URI'];
            if (strpos($actual_uri, '#services') !== false || 
                (isset($_GET['section']) && $_GET['section'] === 'services')) {
                return true;
            }
        }
        return false;
    }
    
    // For other pages, just check if the base filename matches
    return $current_page === basename($base_url);
}
?> 