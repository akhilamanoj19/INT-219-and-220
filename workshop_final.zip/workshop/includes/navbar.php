<?php 
session_start();
include_once 'navbar_handler.php'; 
// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']); 
$userName = $isLoggedIn ? $_SESSION['user_name'] : '';
$userEmail = $isLoggedIn ? $_SESSION['user_email'] : '';
?>
<!-- Navigation -->
<nav class="fixed top-0 left-0 w-full bg-white/95 shadow-md z-50">
    <div class="container mx-auto px-6 py-4">
        <div class="flex items-center justify-between">
            <a href="index.php" class="text-2xl font-bold text-primary-600 flex items-center space-x-2">
                <i class="fas fa-cog animate-spin-slow text-3xl"></i>
                <span>AutoCare</span>
            </a>
            <div class="hidden md:flex items-center space-x-8">
                <a href="index.php" class="nav-link <?php echo isActive('index.php') ? 'active' : ''; ?>">Home</a>
                <a href="index.php#services" class="nav-link <?php echo isActive('index.php#services') ? 'active' : ''; ?>">Services</a>
                <a href="booking.php" class="nav-link <?php echo isActive('booking.php') ? 'active' : ''; ?>">Book Now</a>
                <a href="my_bookings.php" class="nav-link <?php echo isActive('my_bookings.php') ? 'active' : ''; ?>">My Bookings</a>
                <a href="about.php" class="nav-link <?php echo isActive('about.php') ? 'active' : ''; ?>">About</a>
                <a href="contact.php" class="nav-link <?php echo isActive('contact.php') ? 'active' : ''; ?>">Contact</a>
                <a href="feedback.php" class="nav-link <?php echo isActive('feedback.php') ? 'active' : ''; ?>">Feedback</a>
                
                <!-- Profile Button -->
                <?php if ($isLoggedIn): ?>
                <button id="profileBtn" class="flex items-center justify-center w-10 h-10 rounded-full bg-primary-100 text-primary-600 hover:bg-primary-200 transition-colors focus:outline-none">
                    <i class="fas fa-user"></i>
                </button>
                <?php else: ?>
                <a href="./signUpLogin/login.html" class="nav-link">Login</a>
                <?php endif; ?>
            </div>
            <div class="md:hidden relative">
                <button class="text-gray-700 text-2xl focus:outline-none" onclick="toggleMobileMenu()">
                    <i class="fas fa-bars"></i>
                </button>
                <div id="mobileMenu" class="hidden absolute right-0 mt-4 w-48 bg-white rounded-lg shadow-xl py-2">
                    <a href="index.php" class="block px-4 py-2 text-gray-800 hover:bg-primary-50 <?php echo isActive('index.php') ? 'font-semibold text-primary-600' : ''; ?>">Home</a>
                    <a href="index.php#services" class="block px-4 py-2 text-gray-800 hover:bg-primary-50 <?php echo isActive('index.php#services') ? 'font-semibold text-primary-600' : ''; ?>">Services</a>
                    <a href="booking.php" class="block px-4 py-2 text-gray-800 hover:bg-primary-50 <?php echo isActive('booking.php') ? 'font-semibold text-primary-600' : ''; ?>">Book Now</a>
                    <a href="my_bookings.php" class="block px-4 py-2 text-gray-800 hover:bg-primary-50 <?php echo isActive('my_bookings.php') ? 'font-semibold text-primary-600' : ''; ?>">My Bookings</a>
                    <a href="about.php" class="block px-4 py-2 text-gray-800 hover:bg-primary-50 <?php echo isActive('about.php') ? 'font-semibold text-primary-600' : ''; ?>">About</a>
                    <a href="contact.php" class="block px-4 py-2 text-gray-800 hover:bg-primary-50 <?php echo isActive('contact.php') ? 'font-semibold text-primary-600' : ''; ?>">Contact</a>
                    <a href="feedback.php" class="block px-4 py-2 text-gray-800 hover:bg-primary-50 <?php echo isActive('feedback.php') ? 'font-semibold text-primary-600' : ''; ?>">Feedback</a>
                
                    
                    <?php if ($isLoggedIn): ?>
                    <a href="#" class="block px-4 py-2 text-gray-800 hover:bg-primary-50" onclick="toggleProfileModal(event)">
                        <i class="fas fa-user mr-2"></i>Profile
                    </a>
                    <?php else: ?>
                    <a href="./signUpLogin/login.html" class="block px-4 py-2 text-gray-800 hover:bg-primary-50">
                        <i class="fas fa-sign-in-alt mr-2"></i>Login
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</nav>

<!-- Profile Modal -->
<?php if ($isLoggedIn): ?>
<div id="profileModal" class="fixed inset-0 z-50 flex items-center justify-center hidden">
    <div class="absolute inset-0 bg-black bg-opacity-50" onclick="toggleProfileModal()"></div>
    <div class="relative bg-white rounded-lg shadow-xl max-w-md w-full mx-4 transform transition-transform duration-300 scale-95 opacity-0" id="modalContent">
        <div class="p-6">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-2xl font-bold text-gray-900">User Profile</h3>
                <button onclick="toggleProfileModal()" class="text-gray-500 hover:text-gray-700 focus:outline-none">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="flex items-center space-x-4 mb-6 pb-6 border-b border-gray-200">
                <div class="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center text-primary-600">
                    <i class="fas fa-user text-2xl"></i>
                </div>
                <div>
                    <h4 class="text-xl font-semibold text-gray-900"><?php echo htmlspecialchars($userName); ?></h4>
                    <p class="text-gray-500"><?php echo htmlspecialchars($userEmail); ?></p>
                </div>
            </div>
            
            <div class="space-y-4">
                
                
                <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                <a href="admin/dashboard.php" class="flex items-center space-x-3 text-primary-600 hover:text-primary-700 transition-colors">
                    <i class="fas fa-tachometer-alt w-6"></i>
                    <span>Admin Dashboard</span>
                </a>
                <?php endif; ?>
                
                <div class="pt-4 mt-4 border-t border-gray-200">
                    <a href="signUpLogin/login.html" class="flex items-center space-x-3 text-red-600 hover:text-red-700 transition-colors">
                        <i class="fas fa-sign-out-alt w-6"></i>
                        <span>Logout</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Toggle Profile Modal
    function toggleProfileModal(event) {
        if (event) event.preventDefault();
        
        const modal = document.getElementById('profileModal');
        const modalContent = document.getElementById('modalContent');
        
        if (modal.classList.contains('hidden')) {
            // Open modal
            modal.classList.remove('hidden');
            setTimeout(() => {
                modalContent.classList.remove('scale-95', 'opacity-0');
                modalContent.classList.add('scale-100', 'opacity-100');
            }, 10);
        } else {
            // Close modal
            modalContent.classList.remove('scale-100', 'opacity-100');
            modalContent.classList.add('scale-95', 'opacity-0');
            setTimeout(() => {
                modal.classList.add('hidden');
            }, 300);
        }
    }
    
    // Add event listener to profile button
    document.addEventListener('DOMContentLoaded', function() {
        const profileBtn = document.getElementById('profileBtn');
        if (profileBtn) {
            profileBtn.addEventListener('click', toggleProfileModal);
        }
    });
</script>
<?php endif; ?>

<style>
.nav-link {
    position: relative;
    font-weight: 500;
    color: #333;
    transition: color 0.3s ease;
}

.nav-link:hover {
    color: #007bff;
}

.nav-link.active {
    color: #007bff;
}

.nav-link.active::after {
    content: '';
    position: absolute;
    bottom: -4px;
    left: 0;
    right: 0;
    height: 2px;
    background-color: #007bff;
    border-radius: 2px;
}
</style> 