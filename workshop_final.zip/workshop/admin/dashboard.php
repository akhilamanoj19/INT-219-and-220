<?php
session_start();

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    // Redirect to login page if not admin
    header("Location: ../signUpLogin/login.html");
    exit();
}

// Include database connection
include '../includes/db_connect.php';

// Check and create required tables if they don't exist
function createTableIfNotExists($conn, $tableName) {
    $tableCheck = mysqli_query($conn, "SHOW TABLES LIKE '$tableName'");
    return ($tableCheck && mysqli_num_rows($tableCheck) > 0);
}

// Create the contact_inquiries table if it doesn't exist
if (!createTableIfNotExists($conn, 'contact_inquiries')) {
    $createContactTable = "CREATE TABLE `contact_inquiries` (
        `inquiry_id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(100) NOT NULL,
        `email` varchar(100) NOT NULL,
        `subject` varchar(150) NOT NULL,
        `message` text NOT NULL,
        `submission_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `is_read` tinyint(1) NOT NULL DEFAULT 0,
        `responded_by` varchar(100) DEFAULT NULL,
        `response` text DEFAULT NULL,
        `response_date` datetime DEFAULT NULL,
        PRIMARY KEY (`inquiry_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    mysqli_query($conn, $createContactTable);
}

// Get counts for dashboard cards
$bookingCount = 0;
$feedbackCount = 0;
$contactCount = 0;

// Count bookings
$bookingQuery = "SELECT COUNT(*) as count FROM bookings";
$bookingResult = mysqli_query($conn, $bookingQuery);
if ($bookingResult) {
    $bookingCount = mysqli_fetch_assoc($bookingResult)['count'];
}

// Count feedback submissions
$feedbackQuery = "SELECT COUNT(*) as count FROM feedback";
$feedbackResult = mysqli_query($conn, $feedbackQuery);
if ($feedbackResult) {
    $feedbackCount = mysqli_fetch_assoc($feedbackResult)['count'];
}

// Count contact form submissions
$contactQuery = "SELECT COUNT(*) as count FROM contact_inquiries";
$contactResult = mysqli_query($conn, $contactQuery);
if ($contactResult) {
    $contactCount = mysqli_fetch_assoc($contactResult)['count'];
}

// Handle different sections based on tab parameter
$activeTab = isset($_GET['tab']) ? $_GET['tab'] : 'bookings';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AutoCare Workshop</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fff1f2',
                            100: '#ffe4e6',
                            200: '#fecdd3',
                            300: '#fda4af',
                            400: '#fb7185',
                            500: '#f43f5e',
                            600: '#e11d48',
                            700: '#be123c',
                            800: '#9f1239',
                            900: '#881337',
                            950: '#4c0519',
                        }
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar-item {
            transition: all 0.3s;
        }
        .sidebar-item.active {
            background-color: #be123c;
            color: white;
        }
        .sidebar-item:hover:not(.active) {
            background-color: #fecdd3;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="bg-white w-64 shadow-lg">
            <div class="p-6 bg-primary-700 text-white">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-cog animate-spin text-2xl"></i>
                    <h1 class="text-xl font-bold">AutoCare Admin</h1>
                </div>
                <p class="text-primary-200 text-sm mt-1">Dashboard</p>
            </div>
            <div class="mt-8">
                <nav>
                    <a href="?tab=bookings" class="sidebar-item flex items-center px-6 py-3 space-x-3 <?php echo $activeTab === 'bookings' ? 'active' : ''; ?>">
                        <i class="fas fa-calendar-check w-5"></i>
                        <span>Manage Bookings</span>
                    </a>
                    <a href="?tab=feedback" class="sidebar-item flex items-center px-6 py-3 space-x-3 <?php echo $activeTab === 'feedback' ? 'active' : ''; ?>">
                        <i class="fas fa-comments w-5"></i>
                        <span>Manage Feedback</span>
                    </a>
                    <a href="?tab=contact" class="sidebar-item flex items-center px-6 py-3 space-x-3 <?php echo $activeTab === 'contact' ? 'active' : ''; ?>">
                        <i class="fas fa-envelope w-5"></i>
                        <span>Contact Messages</span>
                    </a>
                    <div class="border-t border-gray-200 my-4"></div>
                 
                    <a href="../signUpLogin/logout.php" class="sidebar-item flex items-center px-6 py-3 space-x-3 text-red-600">
                        <i class="fas fa-sign-out-alt w-5"></i>
                        <span>Logout</span>
                    </a>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="flex-1 overflow-auto">
            <!-- Top Header -->
            <header class="bg-white shadow p-4 flex justify-between items-center">
                <h2 class="text-xl font-semibold text-gray-800">
                    <?php 
                    if ($activeTab === 'bookings') echo 'Booking Management';
                    elseif ($activeTab === 'feedback') echo 'Feedback Management';
                    elseif ($activeTab === 'contact') echo 'Contact Messages';
                    ?>
                </h2>
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <span class="text-gray-700"><?php echo $_SESSION['user_name']; ?></span>
                        <span class="ml-2 bg-green-500 rounded-full w-2 h-2 inline-block"></span>
                    </div>
                </div>
            </header>

            <!-- Dashboard Overview Cards -->
            <div class="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="bg-white rounded-xl shadow p-6 flex items-center space-x-4">
                    <div class="bg-blue-100 p-3 rounded-full">
                        <i class="fas fa-calendar-check text-blue-600 text-xl"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Total Bookings</p>
                        <h3 class="text-2xl font-bold"><?php echo $bookingCount; ?></h3>
                    </div>
                </div>
                <div class="bg-white rounded-xl shadow p-6 flex items-center space-x-4">
                    <div class="bg-yellow-100 p-3 rounded-full">
                        <i class="fas fa-comments text-yellow-600 text-xl"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Feedback Received</p>
                        <h3 class="text-2xl font-bold"><?php echo $feedbackCount; ?></h3>
                    </div>
                </div>
                <div class="bg-white rounded-xl shadow p-6 flex items-center space-x-4">
                    <div class="bg-green-100 p-3 rounded-full">
                        <i class="fas fa-envelope text-green-600 text-xl"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Contact Messages</p>
                        <h3 class="text-2xl font-bold"><?php echo $contactCount; ?></h3>
                    </div>
                </div>
            </div>

            <!-- Tab Content -->
            <div class="p-6">
                <?php if ($activeTab === 'bookings'): ?>
                <!-- Booking Management Section -->
                <div class="bg-white rounded-xl shadow overflow-hidden">
                    <div class="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                        <h3 class="font-semibold text-gray-800">Recent Bookings</h3>
                        <div class="flex space-x-2">
                            <div class="relative">
                                <input type="text" id="bookingSearch" placeholder="Search bookings..." 
                                    class="border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500">
                                <i class="fas fa-search absolute right-3 top-3 text-gray-400"></i>
                            </div>
                        </div>
                    </div>
                    
                    <?php if(isset($_SESSION['admin_success']) && $activeTab === 'bookings'): ?>
                    <div class="p-4 mb-4 bg-green-100 text-green-700 border border-green-200 rounded">
                        <?php echo $_SESSION['admin_success']; ?>
                        <?php unset($_SESSION['admin_success']); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if(isset($_SESSION['admin_error']) && $activeTab === 'bookings'): ?>
                    <div class="p-4 mb-4 bg-red-100 text-red-700 border border-red-200 rounded">
                        <?php echo $_SESSION['admin_error']; ?>
                        <?php unset($_SESSION['admin_error']); ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200" id="bookingTable">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php
                                $bookingsQuery = "SELECT * FROM bookings ORDER BY preferred_date DESC LIMIT 100";
                                $bookingsResult = mysqli_query($conn, $bookingsQuery);
                                
                                if (mysqli_num_rows($bookingsResult) > 0) {
                                    while ($booking = mysqli_fetch_assoc($bookingsResult)) {
                                        $status = $booking['status'] ?? 'pending';
                                        $statusClass = 'bg-yellow-100 text-yellow-800';
                                        if ($status == 'completed') {
                                            $statusClass = 'bg-green-100 text-green-800';
                                        } else if ($status == 'cancelled') {
                                            $statusClass = 'bg-red-100 text-red-800';
                                        }
                                ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $booking['id']; ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo $booking['customer_name']; ?></div>
                                        <div class="text-sm text-gray-500"><?php echo $booking['email']; ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $booking['service_type']; ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo date("M d, Y", strtotime($booking['preferred_date'])); ?> at 
                                        <?php echo date("h:i A", strtotime($booking['preferred_time'])); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $statusClass; ?>">
                                            <?php echo ucfirst($status); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <a href="#" onclick="confirmDelete(<?php echo $booking['id']; ?>, 'booking')" class="text-red-600 hover:text-red-900">Delete</a>
                                    </td>
                                </tr>
                                <?php
                                    }
                                } else {
                                ?>
                                <tr>
                                    <td colspan="6" class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">No bookings found</td>
                                </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="p-4 border-t border-gray-200 text-right">
                        <!-- <a href="all_bookings.php" class="text-primary-600 hover:text-primary-800 text-sm font-medium">View All Bookings →</a> -->
                    </div>
                </div>
                <?php elseif ($activeTab === 'feedback'): ?>
                <!-- Feedback Management Section -->
                <div class="bg-white rounded-xl shadow overflow-hidden">
                    <div class="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                        <h3 class="font-semibold text-gray-800">Recent Feedback</h3>
                        <div class="flex space-x-2">
                            <div class="relative">
                                <input type="text" id="feedbackSearch" placeholder="Search feedback..." 
                                    class="border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500">
                                <i class="fas fa-search absolute right-3 top-3 text-gray-400"></i>
                            </div>
                        </div>
                    </div>
                    
                    <?php if(isset($_SESSION['admin_success']) && $activeTab === 'feedback'): ?>
                    <div class="p-4 mb-4 bg-green-100 text-green-700 border border-green-200 rounded">
                        <?php echo $_SESSION['admin_success']; ?>
                        <?php unset($_SESSION['admin_success']); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if(isset($_SESSION['admin_error']) && $activeTab === 'feedback'): ?>
                    <div class="p-4 mb-4 bg-red-100 text-red-700 border border-red-200 rounded">
                        <?php echo $_SESSION['admin_error']; ?>
                        <?php unset($_SESSION['admin_error']); ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200" id="feedbackTable">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rating</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php
                                $feedbackQuery = "SELECT * FROM feedback ORDER BY created_at DESC LIMIT 100";
                                $feedbackResult = mysqli_query($conn, $feedbackQuery);
                                
                                if (mysqli_num_rows($feedbackResult) > 0) {
                                    while ($feedback = mysqli_fetch_assoc($feedbackResult)) {
                                ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $feedback['id']; ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo $feedback['name']; ?></div>
                                        <div class="text-sm text-gray-500"><?php echo $feedback['email']; ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $feedback['service_type']; ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex text-yellow-400">
                                            <?php 
                                            $rating = intval($feedback['rating']);
                                            for ($i = 1; $i <= 5; $i++) {
                                                if ($i <= $rating) {
                                                    echo '<i class="fas fa-star"></i>';
                                                } else {
                                                    echo '<i class="far fa-star"></i>';
                                                }
                                            }
                                            ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo date("M d, Y", strtotime($feedback['created_at'])); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <a href="#" onclick="confirmDelete(<?php echo $feedback['id']; ?>, 'feedback')" class="text-red-600 hover:text-red-900">Delete</a>
                                    </td>
                                </tr>
                                <?php
                                    }
                                } else {
                                ?>
                                <tr>
                                    <td colspan="6" class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">No feedback found</td>
                                </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="p-4 border-t border-gray-200 text-right">
                        <!-- <a href="all_feedback.php" class="text-primary-600 hover:text-primary-800 text-sm font-medium">View All Feedback →</a> -->
                    </div>
                </div>
                <?php elseif ($activeTab === 'contact'): ?>
                <!-- Contact Messages Section -->
                <div class="bg-white rounded-xl shadow overflow-hidden">
                    <div class="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                        <h3 class="font-semibold text-gray-800">Recent Contact Messages</h3>
                        <div class="flex space-x-2">
                            <div class="relative">
                                <input type="text" id="contactSearch" placeholder="Search messages..." 
                                    class="border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500">
                                <i class="fas fa-search absolute right-3 top-3 text-gray-400"></i>
                            </div>
                        </div>
                    </div>
                    
                    <?php if(isset($_SESSION['admin_success']) && $activeTab === 'contact'): ?>
                    <div class="p-4 mb-4 bg-green-100 text-green-700 border border-green-200 rounded">
                        <?php echo $_SESSION['admin_success']; ?>
                        <?php unset($_SESSION['admin_success']); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if(isset($_SESSION['admin_error']) && $activeTab === 'contact'): ?>
                    <div class="p-4 mb-4 bg-red-100 text-red-700 border border-red-200 rounded">
                        <?php echo $_SESSION['admin_error']; ?>
                        <?php unset($_SESSION['admin_error']); ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200" id="contactTable">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php
                                $contactQuery = "SELECT * FROM contact_inquiries ORDER BY submission_date DESC LIMIT 100";
                                $contactResult = mysqli_query($conn, $contactQuery);
                                
                                if ($contactResult && mysqli_num_rows($contactResult) > 0) {
                                    while ($contact = mysqli_fetch_assoc($contactResult)) {
                                        // Determine status based on is_read and response
                                        $status = 'unread';
                                        $statusClass = 'bg-red-100 text-red-800';
                                        
                                        if (!empty($contact['response'])) {
                                            $status = 'replied';
                                            $statusClass = 'bg-green-100 text-green-800';
                                        } else if ($contact['is_read'] == 1) {
                                            $status = 'read';
                                            $statusClass = 'bg-blue-100 text-blue-800';
                                        }
                                ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $contact['inquiry_id']; ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo $contact['name']; ?></div>
                                        <div class="text-sm text-gray-500"><?php echo $contact['email']; ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $contact['subject']; ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo date("M d, Y", strtotime($contact['submission_date'])); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $statusClass; ?>">
                                            <?php echo ucfirst($status); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <a href="#" onclick="confirmDelete(<?php echo $contact['inquiry_id']; ?>, 'contact')" class="text-red-600 hover:text-red-900">Delete</a>
                                    </td>
                                </tr>
                                <?php
                                    }
                                } else {
                                ?>
                                <tr>
                                    <td colspan="6" class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">No contact messages found</td>
                                </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="p-4 border-t border-gray-200 text-right">
                        <!-- <a href="all_messages.php" class="text-primary-600 hover:text-primary-800 text-sm font-medium">View All Messages →</a> -->
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
    function confirmDelete(id, type) {
        let deleteUrl = '';
        
        switch(type) {
            case 'booking':
                deleteUrl = `delete_booking.php?id=${id}`;
                break;
            case 'feedback':
                deleteUrl = `delete_feedback.php?id=${id}`;
                break;
            case 'contact':
                deleteUrl = `delete_contact.php?id=${id}`;
                break;
        }
        
        if (confirm(`Are you sure you want to delete this ${type}?`)) {
            window.location.href = deleteUrl;
        }
    }

    // Simple search functionality for tables
    document.addEventListener('DOMContentLoaded', function() {
        const setupSearch = (inputId, tableSelector) => {
            const input = document.getElementById(inputId);
            if (input) {
                input.addEventListener('keyup', function() {
                    const searchTerm = this.value.toLowerCase();
                    const table = document.querySelector(tableSelector);
                    const rows = table.querySelectorAll('tbody tr');
                    
                    rows.forEach(row => {
                        const text = row.textContent.toLowerCase();
                        row.style.display = text.includes(searchTerm) ? '' : 'none';
                    });
                });
            }
        };

        setupSearch('bookingSearch', '#bookingTable');
        setupSearch('feedbackSearch', '#feedbackTable');
        setupSearch('contactSearch', '#contactTable');
    });
    </script>
</body>
</html> 