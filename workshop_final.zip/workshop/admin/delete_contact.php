<?php
session_start();

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    // Redirect to login page if not admin
    header("Location: ../signUpLogin/login.html");
    exit();
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['admin_error'] = "No inquiry ID provided for deletion";
    header("Location: dashboard.php?tab=contact");
    exit();
}

// Include database connection
include '../includes/db_connect.php';

// Get the ID and sanitize
$inquiry_id = mysqli_real_escape_string($conn, $_GET['id']);

// Delete the contact inquiry
$deleteQuery = "DELETE FROM contact_inquiries WHERE inquiry_id = '$inquiry_id'";
$result = mysqli_query($conn, $deleteQuery);

if ($result) {
    $_SESSION['admin_success'] = "Contact inquiry deleted successfully";
} else {
    $_SESSION['admin_error'] = "Error deleting contact inquiry: " . mysqli_error($conn);
}

// Redirect back to the contact messages tab
header("Location: dashboard.php?tab=contact");
exit();
?> 