<?php
session_start();

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    // Redirect to login page if not admin
    header("Location: ../signUpLogin/login.html");
    exit();
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['admin_error'] = "No feedback ID provided for deletion";
    header("Location: dashboard.php?tab=feedback");
    exit();
}

// Include database connection
include '../includes/db_connect.php';

// Get the ID and sanitize
$feedback_id = mysqli_real_escape_string($conn, $_GET['id']);

// Delete the feedback
$deleteQuery = "DELETE FROM feedback WHERE id = '$feedback_id'";
$result = mysqli_query($conn, $deleteQuery);

if ($result) {
    $_SESSION['admin_success'] = "Feedback deleted successfully";
} else {
    $_SESSION['admin_error'] = "Error deleting feedback: " . mysqli_error($conn);
}

// Redirect back to the feedback tab
header("Location: dashboard.php?tab=feedback");
exit();
?> 