<?php
session_start();

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    // Redirect to login page if not admin
    header("Location: ../signUpLogin/login.html");
    exit();
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['admin_error'] = "No booking ID provided for deletion";
    header("Location: dashboard.php?tab=bookings");
    exit();
}

// Include database connection
include '../includes/db_connect.php';

// Get the ID and sanitize
$booking_id = mysqli_real_escape_string($conn, $_GET['id']);

// Delete the booking
$deleteQuery = "DELETE FROM bookings WHERE id = '$booking_id'";
$result = mysqli_query($conn, $deleteQuery);

if ($result) {
    $_SESSION['admin_success'] = "Booking deleted successfully";
} else {
    $_SESSION['admin_error'] = "Error deleting booking: " . mysqli_error($conn);
}

// Redirect back to the bookings tab
header("Location: dashboard.php?tab=bookings");
exit();
?> 